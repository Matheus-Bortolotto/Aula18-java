package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class desafio {

    public static void main(String[] args) {
        // Configuração da janela do formulário
        JFrame frame = new JFrame("Formulário de Contato");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configuração do painel com FlowLayout
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));  // Ajuste do espaçamento entre os componentes
        panel.setBackground(Color.decode("#f0f0f0")); // Cor de fundo claro para o painel

        // Estilo para os rótulos (Labels)
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Color labelColor = Color.decode("#333333");

        // Nome
        JLabel nomeLabel = new JLabel("Nome:");
        nomeLabel.setFont(labelFont);
        nomeLabel.setForeground(labelColor);
        JTextField nomeField = new JTextField(20);

        // Comentário
        JLabel comentarioLabel = new JLabel("Comentário:");
        comentarioLabel.setFont(labelFont);
        comentarioLabel.setForeground(labelColor);
        JTextArea comentarioArea = new JTextArea(5, 20);
        comentarioArea.setLineWrap(true);
        comentarioArea.setWrapStyleWord(true);

        // Interesse em AWS
        JCheckBox interesseAWS = new JCheckBox("Tem interesse em AWS?");
        interesseAWS.setFont(new Font("Arial", Font.PLAIN, 12));

        // Opções de Sim/Não
        JLabel radioLabel = new JLabel("Você conhece AWS?");
        radioLabel.setFont(labelFont);
        radioLabel.setForeground(labelColor);
        JRadioButton radioSim = new JRadioButton("Sim");
        JRadioButton radioNao = new JRadioButton("Não");
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(radioSim);
        grupo.add(radioNao);

        // Botão Enviar
        JButton enviarButton = new JButton("Enviar");
        enviarButton.setBackground(Color.decode("#4CAF50"));
        enviarButton.setForeground(Color.WHITE);
        enviarButton.setFont(new Font("Arial", Font.BOLD, 14));

        // Adicionando os componentes ao painel
        panel.add(nomeLabel);
        panel.add(nomeField);

        panel.add(comentarioLabel);
        panel.add(new JScrollPane(comentarioArea));

        panel.add(interesseAWS);

        panel.add(radioLabel);
        panel.add(radioSim);
        panel.add(radioNao);

        panel.add(enviarButton);

        // Ação do botão
        enviarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String comentario = comentarioArea.getText();

                // Validação simples
                if (nome.isEmpty() || comentario.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Por favor, preencha todos os campos.", "Erro", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Simulando envio de dados
                    JOptionPane.showMessageDialog(frame, "Formulário enviado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Nome: " + nome + ", Comentário: " + comentario);
                }
            }
        });

        // Adiciona o painel ao JFrame
        frame.add(panel);
        frame.setVisible(true);
    }
}
